# Prop Firm AI — Bot de Telegram
## Instrucciones para subir a Railway (GRATIS)

---

## PASO 1 — Crear el bot en Telegram (2 minutos)

1. Abrí Telegram y buscá **@BotFather**
2. Escribí `/newbot`
3. Te pide un nombre para el bot → escribí por ejemplo: `Prop Firm AI`
4. Te pide un username (debe terminar en "bot") → ejemplo: `propfirmai_bot`
5. BotFather te manda un mensaje con el TOKEN — copialo, se ve así:
   `7234567890:AAHxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx`
6. Guardalo bien, lo vas a necesitar en el Paso 3

---

## PASO 2 — Crear cuenta en Railway (gratis)

1. Entrá a https://railway.app
2. Hacé click en "Start a New Project"
3. Registrate con tu cuenta de GitHub o Google
4. Railway te da $5 de crédito gratis por mes — más que suficiente para este bot

---

## PASO 3 — Subir el bot a Railway

1. En Railway hacé click en **"New Project"** → **"Deploy from GitHub repo"**
   - Si no tenés GitHub: hacé click en **"Empty Project"** → **"Add a Service"** → **"GitHub Repo"**
   - Alternativa sin GitHub: usá **"Deploy from template"** → buscás "Python"

2. **Opción más fácil (sin GitHub):**
   - En Railway: New Project → Empty Project
   - Click en "+ New" → "GitHub Repo" → conectá tu GitHub
   - Subí los archivos `bot.py` y `requirements.txt` a un repo de GitHub primero
   - Railway lo detecta automáticamente

3. **Variables de entorno** (MUY IMPORTANTE):
   Una vez que el proyecto está creado, andá a **"Variables"** y agregá:
   
   | Variable | Valor |
   |----------|-------|
   | `TELEGRAM_TOKEN` | El token que te dio BotFather |
   | `ANTHROPIC_API_KEY` | Tu API key de console.anthropic.com |

4. En **"Settings"** → **"Deploy"** → asegurate que el Start Command sea:
   ```
   python bot.py
   ```

5. Click en **"Deploy"** — en 2 minutos el bot está online

---

## PASO 4 — Probar el bot

1. Buscá tu bot en Telegram por el username que elegiste
2. Escribí `/start`
3. ¡Listo! El bot responde

---

## Comandos disponibles en el bot

| Comando | Función |
|---------|---------|
| `/start` | Menú principal con botones |
| `/challenge` | Estrategias para pasar challenges rápido |
| `/riesgo` | Gestión de riesgo según tu perfil |
| `/colchon` | Cómo armar el buffer de seguridad |
| `/comparar` | Comparar prop firms |
| `/scam` | Detectar señales de scam |
| `/reset` | Limpiar la conversación |
| `/help` | Lista de comandos |

También funciona con chat libre — escribís cualquier pregunta y responde.

---

## Agregar el bot a un grupo

1. Abrí tu grupo de Telegram
2. Click en el nombre del grupo → "Agregar miembros"
3. Buscá tu bot por username
4. Agregalo como miembro (no necesita ser admin para responder mensajes)
5. En el grupo, el bot responde cuando alguien le escribe directamente o cuando usan los comandos

---

## Costo estimado

- Railway: GRATIS (hasta $5/mes de crédito, el bot consume ~$0.50-1/mes)
- Anthropic API: ~$0.01-0.03 por conversación de 10 mensajes
- Para una comunidad de 50-100 usuarios activos: menos de $5/mes en total

---

## Alternativa: Render.com (también gratis)

1. Entrá a https://render.com
2. New → Web Service → conectás tu repo de GitHub
3. Runtime: Python 3
4. Build Command: `pip install -r requirements.txt`
5. Start Command: `python bot.py`
6. En "Environment Variables" agregás TELEGRAM_TOKEN y ANTHROPIC_API_KEY
7. Deploy

⚠️ En el plan gratis de Render el servicio se "duerme" tras 15 min de inactividad.
Para evitarlo usá Railway que mantiene el bot siempre activo.
